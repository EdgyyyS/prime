import { GoogleGenerativeAI } from "@google/generative-ai";

export const handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Method Not Allowed. Use POST." }),
    };
  }

  try {
    const { message, history = [] } = JSON.parse(event.body);

    if (!message || message.trim() === "") {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Mensagem vazia." }),
      };
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("GEMINI_API_KEY não configurada.");

    const client = new GoogleGenerativeAI({ apiKey });

    const response = await client.chat({
      model: "gemini-1.5-flash",
      messages: [
        {
          author: "system",
          content: `
Você é a Consciência Digital do Enzo.
Responda de forma curta, objetiva e profissional.
Se pedirem orçamento ou contato, direcione para WhatsApp.
Nunca escreva nada ofensivo ou irrelevante.
`
        },
        ...history,
        { author: "user", content: message },
      ],
      temperature: 0.7,
    });

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reply: response.output[0].content[0].text }),
    };

  } catch (error) {
    console.error("Erro na função chat:", error);

    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        reply: "Desculpe, o seu dev é lindo demais <3.",
      }),
    };
  }
};
